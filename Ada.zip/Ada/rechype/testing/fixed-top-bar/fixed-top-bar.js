
  const I18N = {
    en: {
      langbar_title: "Idioma / Language",
      menu_home: "Home",
      menu_login: "Login",
      menu_trending: "Trending",
      menu_entries: "Entries",
      menu_mains: "Main Dishes",
      menu_drinks: "Drinks",
      menu_desserts: "Desserts",

      hero_title: "Where technology finds the flavour",
      hero_sub: "Discover a new way to cook, explore, and be inspired. Simple, quick, and smart. From seasoned chefs to first-timers — transform ingredients into experiences.",
      cta_trending: "Explore trending",
      cta_login: "Login",

      pill_smart: "Smart cooking",
      feat_search: "Search by ingredients, styles, or preparation time",

      sec_entries: "Trending Entries",
      sub_entries: "Start light, start bright",
      tag_fresh: "fresh",

      sec_mains: "Trending Main Dishes",
      sub_mains: "Balanced, bold, and built for performance",
      tag_power: "power",

      sec_drinks: "Trending Drinks",
      sub_drinks: "High‑resolution sips",
      tag_refresh: "refresh",

      sec_desserts: "Trending Desserts",
      sub_desserts: "Dramatic endings",
      tag_sweet: "sweet",

      sec_how: "How it works",
      sub_how: "Simple, quick and smart",
      how_1_t: "1. Search",
      how_1_d: "Filter by ingredients, cuisine style, or prep time.",
      how_2_t: "2. Cook",
      how_2_d: "Follow clear steps with tips and variations for everyday life.",
      how_3_t: "3. Personalize",
      how_3_d: "Save, adjust servings, and get smart suggestions.",

      footer_copy: "© 2023 RecHYPE. All rights reserved."
    },
    pt: {
      langbar_title: "Idioma / Language",
      menu_home: "Início",
      menu_login: "Entrar",
      menu_trending: "Em alta",
      menu_entries: "Entradas",
      menu_mains: "Pratos principais",
      menu_drinks: "Bebidas",
      menu_desserts: "Sobremesas",

      hero_title: "Onde a tecnologia encontra o sabor",
      hero_sub: "Descubra um novo jeito de cozinhar, explorar e se inspirar. Simples, rápido e inteligente. De chefs experientes a iniciantes — transforme ingredientes em experiências.",
      cta_trending: "Explorar em alta",
      cta_login: "Entrar",

      pill_smart: "Cozinha inteligente",
      feat_search: "Busque por ingredientes, estilos ou tempo de preparo",

      sec_entries: "Entradas em alta",
      sub_entries: "Comece leve, comece brilhante",
      tag_fresh: "fresco",

      sec_mains: "Pratos principais em alta",
      sub_mains: "Equilíbrio e potência no ponto certo",
      tag_power: "energia",

      sec_drinks: "Bebidas em alta",
      sub_drinks: "Goles em alta resolução",
      tag_refresh: "refrescar",

      sec_desserts: "Sobremesas em alta",
      sub_desserts: "Finais dramáticos",
      tag_sweet: "doce",

      sec_how: "Como funciona",
      sub_how: "Simples, rápido e inteligente",
      how_1_t: "1. Busque",
      how_1_d: "Filtre por ingredientes, estilo culinário ou tempo de preparo.",
      how_2_t: "2. Cozinhe",
      how_2_d: "Siga passos claros, com dicas e variações para o seu dia a dia.",
      how_3_t: "3. Personalize",
      how_3_d: "Salve, ajuste porções e receba sugestões inteligentes.",

      footer_copy: "© 2023 RecHYPE. Todos os direitos reservados."
    }
  };

  function t(lang, key) {
    return (I18N[lang] && I18N[lang][key]) || I18N.en[key] || "";
  }

  function applyTranslations(lang) {
    document.querySelectorAll("[data-i18n]").forEach(el => {
      const key = el.getAttribute("data-i18n");
      const value = t(lang, key);
      if (value) el.textContent = value;
    });

    // data-i18n-attr="placeholder:chat_placeholder,aria-label:x")
    document.querySelectorAll("[data-i18n-attr]").forEach(el => {
      const entries = el.getAttribute("data-i18n-attr").split(",").map(s => s.trim());
      entries.forEach(pair => {
        const [attr, key] = pair.split(":").map(s => s.trim());
        const value = t(lang, key);
        if (attr && value) el.setAttribute(attr, value);
      });
    });

    document.documentElement.lang = (lang === "pt") ? "pt-BR" : "en";
    document.documentElement.setAttribute("data-lang", lang);

    const btnPT = document.getElementById("btn-pt");
    const btnEN = document.getElementById("btn-en");
    [btnPT, btnEN].forEach(btn => {
      const isActive = btn && btn.dataset.lang === lang;
      if (btn) {
        btn.classList.toggle("active", isActive);
        btn.setAttribute("aria-pressed", isActive ? "true" : "false");
      }
    });
  }

  function setLanguage(lang) {
    localStorage.setItem("rechype_lang", lang);
    applyTranslations(lang);
  }

  document.addEventListener("DOMContentLoaded", () => {
    const saved = localStorage.getItem("rechype_lang");
    const preferred = saved || (navigator.language || "").toLowerCase().startsWith("pt") ? "pt" : "en";
    applyTranslations(preferred);

    const btnPT = document.getElementById("btn-pt");
    const btnEN = document.getElementById("btn-en");
    btnPT && btnPT.addEventListener("click", () => setLanguage("pt"));
    btnEN && btnEN.addEventListener("click", () => setLanguage("en"));
  });
