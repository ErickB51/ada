function changeRecipesBtn() {
  const btn = document.getElementById("btn-recipes");
  const menu = document.getElementById("trending-links");
  const icon = document.getElementById("expand-condense-icon");
  const isOpen = btn.classList.toggle("active");

  menu.style.display = isOpen ? "block" : "none";
  btn.setAttribute("aria-expanded", String(isOpen));
  if (icon) {
    if (isOpen) { icon.classList.replace("fa-caret-down", "fa-caret-up"); }
    else { icon.classList.replace("fa-caret-up", "fa-caret-down"); }
  }
}

document.addEventListener("DOMContentLoaded", () => {
  const btn = document.getElementById("btn-recipes");
  btn && btn.addEventListener("click", changeRecipesBtn);
});

document.addEventListener("click", (e) => {
  const btn = document.getElementById("btn-recipes");
  const menu = document.getElementById("trending-links");
  if (!btn || !menu) return;
  const within = btn.contains(e.target) || menu.contains(e.target);
  if (!within && btn.classList.contains("active")) {
    btn.classList.remove("active");
    btn.setAttribute("aria-expanded", "false");
    menu.style.display = "none";
    const icon = document.getElementById("expand-condense-icon");
    icon && icon.classList.replace("fa-caret-up", "fa-caret-down");
  }
});

document.addEventListener("keydown", (e) => {
  if (e.key === "Escape") {
    const btn = document.getElementById("btn-recipes");
    const menu = document.getElementById("trending-links");
    if (btn && btn.classList.contains("active")) {
      btn.classList.remove("active");
      btn.setAttribute("aria-expanded", "false");
      menu.style.display = "none";
      const icon = document.getElementById("expand-condense-icon");
      icon && icon.classList.replace("fa-caret-up", "fa-caret-down");
    }
  }
});

function toggleChatbot() {
  document.getElementById('chatbot-window').classList.toggle('open');
}

function sendMessage() {
  const input = document.getElementById('user-input');
  const msg = input.value.trim();
  if (!msg) return;
  const body = document.getElementById('chat-body');

  const userDiv = document.createElement('div');
  userDiv.className = 'user';
  userDiv.textContent = msg;
  body.appendChild(userDiv);

  input.value = '';

  setTimeout(() => {
    const botDiv = document.createElement('div');
    botDiv.className = 'bot';
    botDiv.textContent = generateResponse(msg.toLowerCase());
    body.appendChild(botDiv);
    body.scrollTop = body.scrollHeight;
  }, 600);
}

function generateResponse(msg) {
  if (msg.includes('ingrediente')) return 'Você pode procurar por receitas usando o que tem na despensa.';
  if (msg.includes('sugestão')) return 'Que tal testar a Cloud Cake como sobremesa leve e sofisticada?';
  if (msg.includes('ajuda')) return 'Claro! Posso te mostrar os pratos em destaque ou ensinar passo a passo.';
  return 'Desculpe, ainda estou aprendendo! Tente perguntar sobre receitas, ingredientes ou sugestões.';
}